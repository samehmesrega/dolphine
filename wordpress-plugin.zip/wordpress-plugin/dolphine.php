<?php
/**
 * Plugin Name: Dolphine
 * Description: يربط نماذج ووردبريس (مثل Contact Form 7) بتطبيق Dolphine. ضع رابط الويب هوك من التطبيق وسيتم إرسال كل إرسال نموذج كليد تلقائياً.
 * Version: 1.0.0
 * Author: Dolphine
 * Text Domain: dolphine
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DOLPHIN_LEADS_OPTION', 'dolphin_leads_webhook_url');

// إعدادات في لوحة التحكم
add_action('admin_menu', function () {
    add_options_page(
        'Dolphine - ربط النماذج',
        'Dolphine',
        'manage_options',
        'dolphine',
        'dolphin_leads_settings_page'
    );
});

add_action('admin_init', function () {
    register_setting('dolphin_leads_settings', DOLPHIN_LEADS_OPTION, [
        'type'              => 'string',
        'sanitize_callback' => 'esc_url_raw',
    ]);
});

function dolphin_leads_settings_page() {
    $url = get_option(DOLPHIN_LEADS_OPTION, '');
    ?>
    <div class="wrap">
        <h1>ربط النماذج مع تطبيق Dolphine</h1>
        <p>من تطبيق Dolphine: اذهب إلى <strong>الربط (ووردبريس / ووكومرس)</strong> → أضف اتصال نموذج → انسخ <strong>رابط الويب هوك</strong> والصقه أدناه.</p>
        <form method="post" action="options.php">
            <?php settings_fields('dolphin_leads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="<?php echo esc_attr(DOLPHIN_LEADS_OPTION); ?>">رابط الويب هوك</label></th>
                    <td>
                        <input type="url" name="<?php echo esc_attr(DOLPHIN_LEADS_OPTION); ?>" id="<?php echo esc_attr(DOLPHIN_LEADS_OPTION); ?>"
                               value="<?php echo esc_attr($url); ?>" class="large-text" placeholder="https://your-api.com/api/webhooks/leads/xxxxx" />
                        <p class="description">الرابط الذي يبدأ بـ /api/webhooks/leads/ من تطبيق Dolphine.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('حفظ'); ?>
        </form>
    </div>
    <?php
}

/**
 * إرسال بيانات النموذج إلى Dolphine
 * يدعم: Contact Form 7، وأي نموذج يرسل بيانات عبر $_POST
 */
function dolphin_leads_send_to_app($payload) {
    $url = get_option(DOLPHIN_LEADS_OPTION, '');
    if (empty($url) || strpos($url, '/api/webhooks/leads/') === false) {
        return;
    }

    wp_remote_post($url, [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode($payload),
        'blocking' => false, // عدم انتظار الرد لسرعة تحميل الصفحة
    ]);
}

// Contact Form 7: عند إرسال النموذج
add_action('wpcf7_submit', function ($contact_form, $result) {
    if ($result['status'] !== 'mail_sent' && $result['status'] !== 'mail_failed') {
        return;
    }
    $submission = \WPCF7_Submission::get_instance();
    if (!$submission) {
        return;
    }
    $posted = $submission->get_posted_data();
    if (empty($posted)) {
        return;
    }
    dolphin_leads_send_to_app($posted);
}, 20, 2);

// Elementor Forms: إرسال بعد النجاح
add_action('elementor_pro/forms/new_record', function ($record, $handler) {
    $settings = $record->get('form_settings');
    $sent_data = $record->get('sent_data');
    if (empty($sent_data) || !is_array($sent_data)) {
        return;
    }
    dolphin_leads_send_to_app($sent_data);
}, 10, 2);

// نماذج أخرى: يمكن استخدام الـ hook من أي كود أو بلجن
// do_action('dolphine_form_submitted', array('your-name' => '...', 'your-phone' => '...', 'your-email' => '...'));
add_action('dolphine_form_submitted', function ($payload) {
    if (is_array($payload)) {
        dolphin_leads_send_to_app($payload);
    }
}, 10, 1);
add_action('dolphin_leads_form_submitted', function ($payload) {
    if (is_array($payload)) {
        dolphin_leads_send_to_app($payload);
    }
}, 10, 1);
